#define	_XOPEN_SOURCE 			/*  */

#include<stdio.h>
#include<sys/socket.h>
#include<arpa/inet.h> //inet_addr
#include <strings.h>
       #include <fcntl.h>
#include <unistd.h>
#include <zhao/tools.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/select.h>
#include "getline.h"
//read /n

enum {
    LISTEN,
    CONN,
};

typedef struct FD {
    int fd;
    int type;
} fd_t;

static 
void set_nonblock(int fd) {
    int flag = fcntl(fd, F_GETFL, 0);
    E_TEST(-1, flag);
    E_TEST(-1, fcntl(fd, F_SETFL, flag |= O_NONBLOCK)); 
}

/*static                                                   */
/*void set_block(int fd) {                                 */
/*    int flag = fcntl(fd, F_GETFL, 0);                    */
/*    E_TEST(-1, flag);                                    */
/*    E_TEST(-1, fcntl(fd, F_SETFL, flag &= ~O_NONBLOCK)); */
/*}                                                        */


void worker(int sock_client) {
    printf("new worker \n");
    char buf[100] ={0};        
    while (1) {
        getline(buf, sock_client);                 
        printf("revice data|%u:%d|:%s\n", getpgrp(), sock_client, buf);    
        write(sock_client, "100\n", strlen("100\n"));
        if (strcmp(buf, "0") == 0) {
            break;
        }
    }
    close(sock_client);
    printf("close connect\n");
    /*exit(0);*/
}


#define	PORT 8888			/*  */
#define	MAX_CONNS 10			/*  */
static fd_t conns[MAX_CONNS];
fd_set rset;


int find_nonused_pos() {
    for (int i=0; i < MAX_CONNS; ++i) {
        if (conns[i].fd == 0)
            return i;
    }
    printf("conns full\n");
    exit(1);
}

int find_max_fd() {
    int max_fd = -1;
    for (int i=0; i < MAX_CONNS; ++i) {
        if (conns[i].fd > max_fd)
            max_fd = conns[i].fd;
    }
    return max_fd;
}

void insert_new_fd(int fd, int type) {
    int i = find_nonused_pos();

    conns[i].fd = fd;
    conns[i].type =  type;
    set_nonblock(fd);
    FD_SET(fd, &rset);
}

void delete_conn(int pos) {
    /*int fd = conns[pos].fd;*/
    FD_CLR(conns[pos].fd, &rset);
    close(conns[pos].fd);
    conns[pos].fd = 0;
}

void try_accept(int pos) {
    struct sockaddr_in client;
    int sock_client;
    socklen_t client_len = sizeof(client);
again:
    sock_client = accept(conns[pos].fd, 
                         (struct sockaddr *)&client, 
                         &client_len);
    if (sock_client == -1) {
        switch (errno) {
        case EINTR:
            goto again;
        case EAGAIN:
            /*printf("accept not new connection\n");*/
            return;
        default:
            perror("accept");
            exit(1);
        }
        return;
    }

    printf("accept a new connect:ip:%s prot:%d\n", 
           inet_ntoa(client.sin_addr),
           ntohs(client.sin_port));

    insert_new_fd(sock_client, CONN);
}

void try_read(int pos) {
    char buf[100] ={0};                                                
    int sock_client = conns[pos].fd;

    getline(buf, sock_client);                                         
    if (buf[0] == '\0')
        return;

    printf("revice data|%u:%d|:%s\n", getpgrp(), sock_client, buf);    
    write(sock_client, "100\n", strlen("100\n"));                      
    if (strcmp(buf, "0") == 0) {                                       
        delete_conn(pos);
    }                                                                  

}

int main()
{
    printf("pid:%u:g:%u\n", getpid(), getpgrp());
    FD_ZERO(&rset);
    int listen_df;
    //Create socket
    EV_TEST(-1, listen_df, socket(AF_INET , SOCK_STREAM , 0));
    printf("create socket succeed\n");

    struct sockaddr_in server;
    bzero(&server, sizeof(server));
    server.sin_family = AF_INET;
    server.sin_port = htons(PORT);
    server.sin_addr.s_addr = INADDR_ANY;

    //Bind
    E_TEST(-1, bind(listen_df,(struct sockaddr *)&server , sizeof(server)));
    E_TEST(-1, listen(listen_df , 3));

    insert_new_fd(listen_df, LISTEN);

    //Accept and incoming connection
    puts("Waiting for incoming connections...");
    /*struct timeval t;*/
    /*t.tv_sec = 100;*/
    /*t.tv_usec = 1000;*/

    /*int max_fd = fd;*/
    while (1) {
        printf("selecting....\n");
        int s = select(find_max_fd()+1, &rset, NULL, NULL, NULL);
        printf("selecting retur %d\n", s);
        if (s == -1) {
            perror("select:");
            exit(1);
        }
        //TODO s

        for (int i=0; i < 10; ++i) {
            if (conns[i].fd == 0)
                continue;
            switch (conns[i].type) {
            case LISTEN:
                try_accept(i);
                break;
            case CONN:
                try_read(i);
                break;
            default:
                printf("unknown TYPE %d\n", conns[i].type);
            }
        }


    }


    return 0;
}
