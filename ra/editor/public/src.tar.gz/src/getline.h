void getline(char buf[], int fd) {
    char c;
    int i;
    for (i=0; ; ++i ) {
        if (-1 == read(fd, &c, 1)) {
          if (errno ==  EAGAIN)
            break;
          perror("read failed");
          exit(1);
        }
        buf[i] = c;
        if (c == '\n')
          break;
    }
    buf[i] = '\0';
}
