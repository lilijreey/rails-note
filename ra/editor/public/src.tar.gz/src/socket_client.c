#define	_XOPEN_SOURCE 			/*  */
#include <sys/socket.h>
#include <sys/types.h>
#include <netinet/in.h>
#include <netdb.h>
#include <stdio.h>
#include <string.h>
#include <strings.h>
#include <stdlib.h>
#include <unistd.h>
#include <zhao/tools.h>
#include <arpa/inet.h>

#include "getline.h"

int main(void) {
    printf("%u:%u\n", getpid(), getpgrp());
    int sockfd = socket(AF_INET, SOCK_STREAM, 0);
    struct sockaddr_in serv_addr;
    bzero(&serv_addr, sizeof(serv_addr));

    serv_addr.sin_family = AF_INET;
    serv_addr.sin_port = htons(8888); //port
    serv_addr.sin_addr.s_addr = inet_addr("127.0.0.1"); //ip

    printf("connecting.... \n");
    E_TEST(-1, connect(sockfd, (struct sockaddr *)&serv_addr, 
            sizeof(serv_addr)));
    printf("connect successed\n");


    char buf[100]={0};
    for (int i=10; i >= 0; --i) {
        sleep(1);
        sprintf(buf, "%d\n", i);
        printf("send: %s\n", buf);
        write(sockfd, buf, strlen(buf));

        getline(buf, sockfd);
    }

    close(sockfd);
}
